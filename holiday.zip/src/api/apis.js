const axios = require('axios')

function sliceArray(array, size) {
    var result = [];
    for (var x = 0; x < Math.ceil(array.length / size); x++) {
        var start = x * size;
        var end = start + size;
        result.push(array.slice(start, end));
    }
    return result;
}

export default {
    async HouseInfo(value) {
        return axios.default
            .get(`https://minsu.dianping.com/api/phx/cprod/products?cityId=${value}`)
            .then((res) => {
                return sliceArray(res.data.data.list, 6);
            })
            .catch((error) => {
                return error;
            });
    },
    async getHoliday(country, year) {
        return axios.default
            .get(`https://holidayapi.com/v1/holidays?pretty&key=8be710c0-7261-4dde-bfc7-162be4e7c1f5&country=${country}&year=${year}`)
            .then(res => {
                return res
            })
            .catch(error => {
                console.error(error);
            })
    },
    async getCountries() {
        return axios.default
            .get(`https://holidayapi.com/v1/countries?pretty&key=8be710c0-7261-4dde-bfc7-162be4e7c1f5`)
            .then(res => {
                return res
            })
            .catch(error => {
                console.error(error);
            })
    },
    async getLocationID(city) {
        return axios.default
            .get(`https://geoapi.qweather.com/v2/city/lookup?location=${city}&key=3792e54aeee34449a334770f0b6b9cba`)
            .then(res => {
                return res.data.location[0].id
            })
            .catch(error => {
                console.error(error);
            })
    },
    async getWeather(LocationID) {
        return axios.default
            .get(`https://devapi.qweather.com/v7/weather/3d?location=${LocationID}&key=3792e54aeee34449a334770f0b6b9cba`)           
            .then(res => {
                return res
            })
            .catch(error => {
                console.error(error);
            })


    }
}