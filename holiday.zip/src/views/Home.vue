<template>
  <div class="home">
    <el-alert
      type="info"
      show-icon
      title="please selecte a country to view the holidays,the default yeart is 2020"
      effect="dark"
    >
    </el-alert>
    <span>please select or input a country：</span
    ><el-select
      v-model="country"
      filterable
      default-first-option
      placeholder="please select a country"
      @change="showTbl"
    >
      <el-option
        v-for="(item, index) in countries"
        :key="index"
        :label="item.name"
        :value="item.code"
      >
        <span style="float: left">{{ item.name }}</span>
        <span style="float: right; color: #8492a6; font-size: 13px">{{
          item.code
        }}</span>
      </el-option>
    </el-select>
    <el-button type="danger" icon="el-icon-delete" @click="reset"
      >Reset</el-button
    >
  
    <div v-if="holidays.length != 0">
      <el-table
        :data="holidays"
        border
        style="width: 100%"
        :header-cell-style="{ 'text-align': 'center' }"
        :cell-style="{ 'text-align': 'center' }"
        :stripe="true"
      >
        <el-table-column prop="name" label="Name"> </el-table-column>
        <el-table-column prop="country" label="Country"></el-table-column>
        <el-table-column prop="date" label="Date"> </el-table-column>
        <el-table-column
          prop="weekday.date.name"
          label="Weekday"
        ></el-table-column>
        <el-table-column
          prop="public"
          label="IsPublic"
          align="center"
          class-name="public-row"
        >
          <template slot-scope="scope">
            <i
              :class="
                scope.row.public === true ? 'el-icon-check' : 'el-icon-close'
              "
            ></i>
          </template>
        </el-table-column>
      </el-table>
    </div>
  </div>
</template>

<script>
//
import api from "../api/apis";

export default {
  name: "Home",
  data() {
    return {
      country: "",
      countries: [],
      holidays: [],
    };
  },
  methods: {
    getHolidays(countryCOde) {
      api
        .getHoliday(countryCOde, 2020)
        .then((res) => {
          this.holidays = res.data.holidays;
        })
        .catch((err) => {
          console.error(err);
        });
    },
    getCountries() {
      api
        .getCountries()
        .then((res) => {
          this.countries = res.data.countries;
        })
        .catch((err) => {
          console.error(err);
        });
    },
    showTbl(e) {
      this.getHolidays(e);
    },
    reset() {
      this.country='';
      this.holidays = [];
    },
  },
  created() {
    // this.getHolidays();
    this.getCountries();
  },
};
</script>

<style>
.home {
  height: 100vh;
}
.public-row {
  color:red;
  font-weight:800;
}
</style>