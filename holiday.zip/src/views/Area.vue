<template>
  <div class="Area">
    <el-row :gutter="20">
      <el-col :span="12" :offset="6">
        <span>please select a city:</span>
        <el-cascader
          size="large"
          :options="options"
          v-model="selectedOptions"
          @change="selectCity"
          placeholder="select"
        >
        </el-cascader>
      </el-col>
    </el-row>

    <el-tabs v-model="tabName" @tab-click="tabClick">
      <el-tab-pane label="The Weather information" name="weather">
        <el-alert
          :title="lastUpdateTime(weatherList.updateTime)"
          type="info"
          effect="dark"
        >
        </el-alert>

        <el-row :gutter="10">
          <el-col
            :span="8" 
            v-for="(item, index) in weatherList.daily"
            :key="index"
          >
            <el-card
              :body-style="{ padding: '10px', margin: '10px' }"
              shadow="hover"
            >
              <h3>{{ item.fxDate }}</h3>
              <div class="card-bottom">
                <div>
                  <el-image
                    lazy
                    :src="icon(item.iconDay)"
                    fit="fill"
                    class="icon-day"
                    style="width: 80px"
                  ></el-image>
                  <span>白天天气状况：{{ item.textDay }}</span>
                </div>
                <div>
                  <el-image
                    lazy
                    :src="icon(item.iconNight)"
                    fit="fill"
                    class="icon-day"
                    style="width: 80px"
                  ></el-image>
                  <span>夜晚天气状况：{{ item.textNight }}</span>
                </div>

                <h3>
                  最高温度：<el-tag type="info">{{ item.tempMax }}℃</el-tag>
                </h3>
                <h3>
                  最低温度：<el-tag type="info">{{ item.tempMin }} ℃</el-tag>
                </h3>
                <h3>
                  紫外线强度：
                  <el-tag :type="item.uvIndex > 5 ? 'warning' : 'success'">
                    {{ item.uvIndex }}
                  </el-tag>
                </h3>
                <h3 v-if="item.precip == 0.0">
                  降水量(默认单位：毫米)：<el-tag type="info">{{
                    item.precip
                  }}</el-tag>
                </h3>
                <h3>
                  白天风力：<el-tag type="info"
                    >{{ item.windScaleDay }}级</el-tag
                  >
                </h3>
                <h3>
                  夜晚风力：<el-tag type="info"
                    >{{ item.windScaleNight }}级</el-tag
                  >
                </h3>
              </div>
            </el-card>
          </el-col>
        </el-row>
      </el-tab-pane>

      <el-tab-pane label="The Accommodation Information" name="house">
        <div v-if="hashouseList">
          <el-row :gutter="10" v-for="(item, index) in houseList" :key="index">
            <el-col :span="8" v-for="(house, index) in item" :key="index">
              <el-card
                :body-style="{ padding: '10px', margin: '10px' }"
                shadow="hover"
              >
                <el-image
                  lazy
                  :src="house.coverImage"
                  fit="fill"
                  style="width: 580px; height: 440px"
                ></el-image>
                <div style="padding: 14px">
                  <el-link
                    :href="link(house.productId)"
                    :underline="false"
                    icon="el-icon-s-home"
                    type="primary"
                    target="_blank"
                    >{{ house.title }}</el-link
                  >
                  <h3>{{ house.guestNumberDesc }}</h3>
                  <h3>price:￥{{ house.price / 100 }}</h3>
                </div>
              </el-card>
            </el-col>
          </el-row>
        </div>
        <div v-else>
          <el-alert title="please select a city！" type="warning" effect="dark">
          </el-alert>
        </div>
      </el-tab-pane>
    </el-tabs>
  </div>
</template>

<script>
import { provinceAndCityData, CodeToText } from "element-china-area-data";
import api from "../api/apis";

export default {
  name: "Area",
  data() {
    return {
      options: provinceAndCityData,
      selectedOptions: [],
      houseList: [],
      hashouseList: false,
      tabName: "weather",
      weatherList: {},
    };
  },
  computed: {
    link() {
      return function (productID) {
        return `https://minsu.dianping.com/housing/${productID}/`;
      };
    },
    lastUpdateTime() {
      return (time) =>
        time === undefined ? "近三日天气情况" : `天气更新时间:${time}`;
    },
    icon() {
      return (code) => require(`../image/${code}.png`);
    },
  },
  methods: {
    tabClick(tab) {
      console.log(tab.label);
    },
    getHouseInfo(value) {
      api
        .HouseInfo(value[1])
        .then((houses) => {
          this.hashouseList = true;          
          this.houseList = houses;
        })
        .catch((error) => {
          console.error(error);
        });
    },
    getWeather(city) {
      api
        .getLocationID(city)
        .then((LocationID) => {
          console.log(LocationID);
          api
            .getWeather(LocationID)
            .then((weather) => {
              console.log(weather);
              this.weatherList = weather.data;
              
            })
            .catch((error) => {
              console.error(error);
            });
        })
        .catch((error) => {
          console.error(error);
        });
    },

    selectCity(code) {
      console.log(code);
      let city =
        CodeToText[code[1]] === "市辖区"
          ? CodeToText[code[0]].slice(0, -1)
          : CodeToText[code[1]].slice(0, -1);
      // console.log(city);
      this.getHouseInfo(code);
      this.getWeather(city);
    },
  },
  mounted() {},
};
</script>
<style>
.el-row {
  margin-bottom: 20px;
}
.el-col {
  border-radius: 4px;
}
.card-bottom {
  margin-top: 13px;
  line-height: 12px;
}
.icon-day {
  vertical-align: middle;
}
</style>
