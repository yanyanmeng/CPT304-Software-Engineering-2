<template >
  <div id="app">
    <el-menu
      :default-active="active"
      class="el-menu-demo"
      mode="horizontal"
      @select="handleSelect"
      background-color="#545c64"
      text-color="#fff"
      :router="true"
      active-text-color="#ffd04b"
    >
      <el-menu-item index="/">Public Holidays</el-menu-item>
      <el-menu-item index="/Area">Accommodation Information</el-menu-item>
    </el-menu>
    
    <keep-alive include="Area,Home">
      <router-view></router-view>
    </keep-alive>
  </div>
</template>
<script>
export default {
  data() {
    return {
      active: "/",
    };
  },
  methods: {
    handleSelect(key, keyPath) {
      console.log(key, keyPath);
    },
  },
};
</script>

<style>
#app {
  margin: 0;
  padding: 0;
}
</style>

