# holiday

## 概述

## 需求的概要和分析

### 组件选择

	使用vue + elementUI，通过在github以及多个开源论坛寻找到合适API,进行开发

### 验证过程

### 组件组成

#### 省市联动组件

- 采用npm的element-china-area-data包，是已经封装好的一个省市区多级联动的组件。
- 通过文档的测试地址进行API测试

- 地址
  - https://plortinus.github.io/element-china-area-data/index.html
  - https://www.npmjs.com/package/element-china-area-data

#### 房源API

- 通过多个住宿APP,发现美团名宿的API是开放的，所以短租这里使用美团民宿API。
- 通过文档的测试地址进行API测试
- 接口地址
  - https://minsu.dianping.com/api/phx/cprod/products?cityId=
- 接口地址中的cityid通过省市联动组件获取

#### Holidays API

- 从github
- 通过文档的测试地址进行API测试

- 接口文档地址
  - [Developer Documentation - Holiday API](https://holidayapi.com/docs)

#### CountriesAPI

- 接口地址同上

#### WeatherAPI

- 通过对比多个天气API,最后选择和风天气API
- 通过文档的测试地址进行API测试
- 接口地址
  - [API开发文档 | 和风天气开发平台 (qweather.com)](https://dev.qweather.com/docs/api/)

### 解决方案部署步骤，结论，以及附录中的源代码。